from turtle import Turtle
import random

S_POSITION = [(0, 0), (-20, 0), (-40, 0)]
DISTANCE = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0
colors = ["white", "purple", "blue", "yellow", "green"]

class Tosba:
    def __init__(self):
        self.created = []
        self.create_tosba()
        self.head = self.created[0]

    def create_tosba(self):
        for position in S_POSITION:
            self.add_created(position)

    def add_created(self, position):
        new_turtle = Turtle(shape="circle")
        new_turtle.color(random.choice(colors))
        new_turtle.penup()
        new_turtle.goto(position)
        self.created.append(new_turtle)

    def extends(self):
        self.add_created(self.created[-1].position())

    def move(self):
        for cr_num in range(len(self.created) - 1, 0, -1):
            new_x = self.created[cr_num - 1].xcor()
            new_y = self.created[cr_num - 1].ycor()
            self.created[cr_num].goto(new_x, new_y)
        self.created[0].forward(DISTANCE)

    def up(self):
        if self.head.heading() != DOWN:
            self.head.setheading(UP)

    def down(self):
        if self.head.heading() != UP:
            self.head.setheading(DOWN)

    def left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(RIGHT)
