from turtle import Screen
from tosba import Tosba
from food import Food
from score import Score
import time

screen = Screen()
screen.setup(800, 800)
screen.bgcolor("black")
screen.title("My Snake Game")
screen.tracer(0)

tosba = Tosba()
food = Food()
score = Score()

screen.listen()
screen.onkey(tosba.up, "w")
screen.onkey(tosba.down, "s")
screen.onkey(tosba.left, "a")
screen.onkey(tosba.right, "d")


is_on = True
while is_on:
    screen.update()
    time.sleep(0.1)
    tosba.move()

    #Food
    if tosba.head.distance(food) < 15:
        food.refresh()
        tosba.extends()
        score.increase_score()

    #Wall
    if tosba.head.xcor() > 380 or tosba.head.xcor() < -380 or tosba.head.ycor() > 380 or tosba.head.ycor() < -380:
        is_on = False
        score.game_over()

    #Tail
    for create in tosba.created[1:]:
        if tosba.head.distance(create) < 10:
            is_on = False
            score.game_over()

screen.exitonclick()

